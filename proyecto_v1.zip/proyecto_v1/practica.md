# 1.agregar tu usuario desde el insert en la tabla usuarios del sistema
# 2.implementar en el menu una opcion referente al sistema inmobiliario con el flujo desarrollado en clase
# crear la carpeta servicio para el modulo agregar en caso sea necesario
# (referencias o ejemplos en el main.py )
# 3. enviar un email con email.py 
# (ya se encuentra configurado e implementado en login solo cambiar el subject ,mensaje y llamarlo en tu funcionalidad implementada)